/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itpgui1;

//import java.sql.*;
//import com.mysql.jdbc.Connection;

/**
 *
 * @author Kavinda
 */
public class Itpgui1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Connection conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/tourmangementsystem","root","");
        //public static Connection conn2=DBconnect.connect();
        //schedulemain sh1=new schedulemain();
        usrmain u1=new usrmain();
    }
    
}
